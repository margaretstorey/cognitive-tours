(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/app_0b.rhrh._.js","static/chunks/node_modules_0308eh7._.js"],
    source: "dynamic"
});
