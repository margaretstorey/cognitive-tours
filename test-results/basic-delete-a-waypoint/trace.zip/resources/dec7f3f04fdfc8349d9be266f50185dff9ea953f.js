(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/app/lib/types.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "WAYPOINT_TYPES",
    ()=>WAYPOINT_TYPES
]);
const WAYPOINT_TYPES = [
    'Goal',
    'User Need',
    'Feature',
    'ADR',
    'Code Component',
    'Test',
    'Risk',
    'AI Instruction',
    'Open Question'
];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/lib/waypoint-colors.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "WAYPOINT_COLORS",
    ()=>WAYPOINT_COLORS
]);
const WAYPOINT_COLORS = {
    'Goal': 'bg-violet-200 border-violet-600 text-violet-950',
    'User Need': 'bg-blue-100 border-blue-300 text-blue-900',
    'Feature': 'bg-green-100 border-green-300 text-green-900',
    'ADR': 'bg-yellow-100 border-yellow-300 text-yellow-900',
    'Code Component': 'bg-purple-100 border-purple-300 text-purple-900',
    'Test': 'bg-teal-100 border-teal-300 text-teal-900',
    'Risk': 'bg-red-100 border-red-300 text-red-900',
    'AI Instruction': 'bg-orange-100 border-orange-300 text-orange-900',
    'Open Question': 'bg-gray-100 border-gray-300 text-gray-900'
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/WaypointGraph.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>WaypointGraph
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$xyflow$2f$react$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@xyflow/react/dist/esm/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$xyflow$2f$system$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@xyflow/system/dist/esm/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/lib/types.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$waypoint$2d$colors$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/lib/waypoint-colors.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
function WaypointNode({ data, selected }) {
    const colorClass = __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$waypoint$2d$colors$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WAYPOINT_COLORS"][data.waypoint.type];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `px-3 py-2 rounded-lg border-2 text-sm font-medium max-w-[180px] shadow-sm ${colorClass} ${data.isActiveTourStep ? 'ring-4 ring-offset-2 ring-blue-500 shadow-lg shadow-blue-400/50' : selected ? 'ring-2 ring-offset-1 ring-blue-500' : ''}`,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$xyflow$2f$react$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Handle"], {
                type: "target",
                position: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$xyflow$2f$system$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Position"].Left,
                className: "!bg-gray-400"
            }, void 0, false, {
                fileName: "[project]/app/components/WaypointGraph.tsx",
                lineNumber: 37,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-xs opacity-60 mb-0.5",
                children: data.waypoint.type
            }, void 0, false, {
                fileName: "[project]/app/components/WaypointGraph.tsx",
                lineNumber: 38,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "leading-tight",
                children: data.waypoint.label
            }, void 0, false, {
                fileName: "[project]/app/components/WaypointGraph.tsx",
                lineNumber: 39,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$xyflow$2f$react$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Handle"], {
                type: "source",
                position: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$xyflow$2f$system$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Position"].Right,
                className: "!bg-gray-400"
            }, void 0, false, {
                fileName: "[project]/app/components/WaypointGraph.tsx",
                lineNumber: 40,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/components/WaypointGraph.tsx",
        lineNumber: 30,
        columnNumber: 5
    }, this);
}
_c = WaypointNode;
const nodeTypes = {
    waypointNode: WaypointNode
};
function Graph({ waypoints, edges, selectedWaypointId, activeTourWaypointIds, onSelectWaypoint, onConnect, onDeleteEdge, onNodePositionChange, onAddWaypointClick, filterState, onFilterChange, searchQuery, onSearchChange }) {
    _s();
    const [selectedEdgeId, setSelectedEdgeId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [filterPanelOpen, setFilterPanelOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const filterPanelRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const hiddenNodeIds = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "Graph.useMemo[hiddenNodeIds]": ()=>{
            const q = searchQuery.toLowerCase();
            return new Set(waypoints.filter({
                "Graph.useMemo[hiddenNodeIds]": (w)=>!filterState[w.type] || q && !w.label.toLowerCase().includes(q)
            }["Graph.useMemo[hiddenNodeIds]"]).map({
                "Graph.useMemo[hiddenNodeIds]": (w)=>w.id
            }["Graph.useMemo[hiddenNodeIds]"]));
        }
    }["Graph.useMemo[hiddenNodeIds]"], [
        waypoints,
        filterState,
        searchQuery
    ]);
    const hiddenCount = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "Graph.useMemo[hiddenCount]": ()=>__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WAYPOINT_TYPES"].filter({
                "Graph.useMemo[hiddenCount]": (t)=>!filterState[t]
            }["Graph.useMemo[hiddenCount]"]).length
    }["Graph.useMemo[hiddenCount]"], [
        filterState
    ]);
    const nodes = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "Graph.useMemo[nodes]": ()=>waypoints.filter({
                "Graph.useMemo[nodes]": (w)=>!hiddenNodeIds.has(w.id)
            }["Graph.useMemo[nodes]"]).map({
                "Graph.useMemo[nodes]": (w)=>({
                        id: w.id,
                        type: 'waypointNode',
                        position: w.position,
                        data: {
                            waypoint: w,
                            isActiveTourStep: activeTourWaypointIds.length > 0 && w.id === selectedWaypointId
                        },
                        selected: w.id === selectedWaypointId,
                        style: activeTourWaypointIds.length > 0 && !activeTourWaypointIds.includes(w.id) ? {
                            opacity: 0.2
                        } : undefined
                    })
            }["Graph.useMemo[nodes]"])
    }["Graph.useMemo[nodes]"], [
        waypoints,
        selectedWaypointId,
        activeTourWaypointIds,
        hiddenNodeIds
    ]);
    const rfEdges = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "Graph.useMemo[rfEdges]": ()=>edges.filter({
                "Graph.useMemo[rfEdges]": (e)=>!hiddenNodeIds.has(e.source) && !hiddenNodeIds.has(e.target)
            }["Graph.useMemo[rfEdges]"]).map({
                "Graph.useMemo[rfEdges]": (e)=>{
                    const dimmed = activeTourWaypointIds.length > 0 && !(activeTourWaypointIds.includes(e.source) && activeTourWaypointIds.includes(e.target));
                    return {
                        id: e.id,
                        source: e.source,
                        target: e.target,
                        label: dimmed ? undefined : e.label,
                        selected: e.id === selectedEdgeId,
                        style: dimmed ? {
                            opacity: 0.2
                        } : undefined
                    };
                }
            }["Graph.useMemo[rfEdges]"])
    }["Graph.useMemo[rfEdges]"], [
        edges,
        activeTourWaypointIds,
        selectedEdgeId,
        hiddenNodeIds
    ]);
    const [pendingConnection, setPendingConnection] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [pendingLabel, setPendingLabel] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const onNodesChange = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "Graph.useCallback[onNodesChange]": (changes)=>{
            changes.forEach({
                "Graph.useCallback[onNodesChange]": (change)=>{
                    if (change.type === 'position' && change.position) {
                        onNodePositionChange(change.id, change.position);
                    }
                }
            }["Graph.useCallback[onNodesChange]"]);
        }
    }["Graph.useCallback[onNodesChange]"], [
        onNodePositionChange
    ]);
    const onEdgesChange = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "Graph.useCallback[onEdgesChange]": (changes)=>{
            changes.forEach({
                "Graph.useCallback[onEdgesChange]": (change)=>{
                    if (change.type === 'remove') onDeleteEdge(change.id);
                    if (change.type === 'select') setSelectedEdgeId(change.selected ? change.id : null);
                }
            }["Graph.useCallback[onEdgesChange]"]);
        }
    }["Graph.useCallback[onEdgesChange]"], [
        onDeleteEdge
    ]);
    const handleConnect = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "Graph.useCallback[handleConnect]": (connection)=>{
            if (connection.source && connection.target && connection.source !== connection.target) {
                setPendingConnection({
                    source: connection.source,
                    target: connection.target
                });
                setPendingLabel('');
            }
        }
    }["Graph.useCallback[handleConnect]"], []);
    const confirmConnect = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "Graph.useCallback[confirmConnect]": ()=>{
            if (!pendingConnection) return;
            onConnect({
                ...pendingConnection,
                label: pendingLabel.trim() || undefined
            });
            setPendingConnection(null);
        }
    }["Graph.useCallback[confirmConnect]"], [
        pendingConnection,
        pendingLabel,
        onConnect
    ]);
    const cancelConnect = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "Graph.useCallback[cancelConnect]": ()=>{
            setPendingConnection(null);
        }
    }["Graph.useCallback[cancelConnect]"], []);
    const onNodeClick = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "Graph.useCallback[onNodeClick]": (_, node)=>{
            onSelectWaypoint(node.id);
        }
    }["Graph.useCallback[onNodeClick]"], [
        onSelectWaypoint
    ]);
    const onPaneClick = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "Graph.useCallback[onPaneClick]": ()=>{
            onSelectWaypoint(null);
            setFilterPanelOpen(false);
        }
    }["Graph.useCallback[onPaneClick]"], [
        onSelectWaypoint
    ]);
    const onEdgeDoubleClick = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "Graph.useCallback[onEdgeDoubleClick]": (_, edge)=>{
            onDeleteEdge(edge.id);
        }
    }["Graph.useCallback[onEdgeDoubleClick]"], [
        onDeleteEdge
    ]);
    if (waypoints.length === 0) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex h-full items-center justify-center text-gray-400 flex-col gap-3",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    children: "No waypoints yet."
                }, void 0, false, {
                    fileName: "[project]/app/components/WaypointGraph.tsx",
                    lineNumber: 204,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    onClick: onAddWaypointClick,
                    className: "px-4 py-2 bg-blue-600 text-white rounded-lg text-sm hover:bg-blue-700",
                    children: "Add first waypoint"
                }, void 0, false, {
                    fileName: "[project]/app/components/WaypointGraph.tsx",
                    lineNumber: 205,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/WaypointGraph.tsx",
            lineNumber: 203,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$xyflow$2f$react$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ReactFlow"], {
        nodes: nodes,
        edges: rfEdges,
        nodeTypes: nodeTypes,
        onNodesChange: onNodesChange,
        onEdgesChange: onEdgesChange,
        onConnect: handleConnect,
        onNodeClick: onNodeClick,
        onPaneClick: onPaneClick,
        onEdgeDoubleClick: onEdgeDoubleClick,
        fitView: true,
        fitViewOptions: {
            padding: 0.2
        },
        deleteKeyCode: null,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$xyflow$2f$react$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Background"], {}, void 0, false, {
                fileName: "[project]/app/components/WaypointGraph.tsx",
                lineNumber: 230,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$xyflow$2f$react$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Controls"], {}, void 0, false, {
                fileName: "[project]/app/components/WaypointGraph.tsx",
                lineNumber: 231,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "absolute top-3 left-3 z-10 flex gap-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: onAddWaypointClick,
                        className: "px-3 py-1.5 bg-white border border-gray-300 rounded-lg text-sm shadow-sm hover:bg-gray-50",
                        children: "+ Add Waypoint"
                    }, void 0, false, {
                        fileName: "[project]/app/components/WaypointGraph.tsx",
                        lineNumber: 233,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        type: "text",
                        value: searchQuery,
                        onChange: (e)=>onSearchChange(e.target.value),
                        placeholder: "Search…",
                        className: "px-3 py-1.5 bg-white border border-gray-300 rounded-lg text-sm shadow-sm w-40 focus:outline-none focus:border-gray-400"
                    }, void 0, false, {
                        fileName: "[project]/app/components/WaypointGraph.tsx",
                        lineNumber: 239,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        ref: filterPanelRef,
                        className: "relative",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>setFilterPanelOpen((o)=>!o),
                                className: "px-3 py-1.5 bg-white border border-gray-300 rounded-lg text-sm shadow-sm hover:bg-gray-50",
                                children: hiddenCount > 0 ? `Filter (${hiddenCount} hidden)` : 'Filter'
                            }, void 0, false, {
                                fileName: "[project]/app/components/WaypointGraph.tsx",
                                lineNumber: 247,
                                columnNumber: 11
                            }, this),
                            filterPanelOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "absolute top-full left-0 mt-1 bg-white border border-gray-200 rounded-lg shadow-lg p-2 flex flex-col gap-0.5 min-w-[190px]",
                                children: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WAYPOINT_TYPES"].map((type)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        className: "flex items-center gap-2 text-sm px-2 py-1 rounded hover:bg-gray-50 cursor-pointer",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                type: "checkbox",
                                                checked: filterState[type],
                                                onChange: (e)=>onFilterChange(type, e.target.checked),
                                                className: "rounded"
                                            }, void 0, false, {
                                                fileName: "[project]/app/components/WaypointGraph.tsx",
                                                lineNumber: 260,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: `inline-block w-2.5 h-2.5 rounded-full border-2 flex-shrink-0 ${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$waypoint$2d$colors$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WAYPOINT_COLORS"][type]}`
                                            }, void 0, false, {
                                                fileName: "[project]/app/components/WaypointGraph.tsx",
                                                lineNumber: 266,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                children: type
                                            }, void 0, false, {
                                                fileName: "[project]/app/components/WaypointGraph.tsx",
                                                lineNumber: 267,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, type, true, {
                                        fileName: "[project]/app/components/WaypointGraph.tsx",
                                        lineNumber: 256,
                                        columnNumber: 17
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/app/components/WaypointGraph.tsx",
                                lineNumber: 254,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/components/WaypointGraph.tsx",
                        lineNumber: 246,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/components/WaypointGraph.tsx",
                lineNumber: 232,
                columnNumber: 7
            }, this),
            pendingConnection && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "absolute inset-0 z-20 flex items-center justify-center bg-black/20",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "bg-white rounded-xl shadow-xl p-5 flex flex-col gap-3 w-72",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-sm font-medium text-gray-800",
                            children: "Add a label to this connection"
                        }, void 0, false, {
                            fileName: "[project]/app/components/WaypointGraph.tsx",
                            lineNumber: 277,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                            autoFocus: true,
                            className: "border border-gray-300 rounded px-3 py-1.5 text-sm",
                            value: pendingLabel,
                            onChange: (e)=>setPendingLabel(e.target.value),
                            placeholder: "e.g. depends on, implements… (optional)",
                            onKeyDown: (e)=>{
                                if (e.key === 'Enter') confirmConnect();
                                if (e.key === 'Escape') cancelConnect();
                            }
                        }, void 0, false, {
                            fileName: "[project]/app/components/WaypointGraph.tsx",
                            lineNumber: 278,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex gap-2 justify-end",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: cancelConnect,
                                    className: "px-3 py-1.5 text-sm border rounded hover:bg-gray-50",
                                    children: "Cancel"
                                }, void 0, false, {
                                    fileName: "[project]/app/components/WaypointGraph.tsx",
                                    lineNumber: 290,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: confirmConnect,
                                    className: "px-3 py-1.5 text-sm bg-blue-600 text-white rounded hover:bg-blue-700",
                                    children: "Add Connection"
                                }, void 0, false, {
                                    fileName: "[project]/app/components/WaypointGraph.tsx",
                                    lineNumber: 293,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/components/WaypointGraph.tsx",
                            lineNumber: 289,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/components/WaypointGraph.tsx",
                    lineNumber: 276,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/components/WaypointGraph.tsx",
                lineNumber: 275,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/components/WaypointGraph.tsx",
        lineNumber: 216,
        columnNumber: 5
    }, this);
}
_s(Graph, "RN2+RKsPHDDf3+26ju4KrRqK0Fo=");
_c1 = Graph;
function WaypointGraph(props) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$xyflow$2f$react$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ReactFlowProvider"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Graph, {
            ...props
        }, void 0, false, {
            fileName: "[project]/app/components/WaypointGraph.tsx",
            lineNumber: 307,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/app/components/WaypointGraph.tsx",
        lineNumber: 306,
        columnNumber: 5
    }, this);
}
_c2 = WaypointGraph;
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "WaypointNode");
__turbopack_context__.k.register(_c1, "Graph");
__turbopack_context__.k.register(_c2, "WaypointGraph");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/WaypointDetail.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>WaypointDetail
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$waypoint$2d$colors$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/lib/waypoint-colors.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
function WaypointDetail({ waypoint, onEdit, onDelete }) {
    _s();
    if (!waypoint) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex h-full items-center justify-center p-6 text-center text-gray-400 text-sm",
            children: "Select a waypoint to see its details."
        }, void 0, false, {
            fileName: "[project]/app/components/WaypointDetail.tsx",
            lineNumber: 16,
            columnNumber: 7
        }, this);
    }
    const [copied, setCopied] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const colorClass = __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$waypoint$2d$colors$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WAYPOINT_COLORS"][waypoint.type];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "p-4 flex flex-col gap-4",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: `inline-block self-start px-2 py-0.5 rounded text-xs font-medium border ${colorClass}`,
                children: waypoint.type
            }, void 0, false, {
                fileName: "[project]/app/components/WaypointDetail.tsx",
                lineNumber: 27,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                className: "text-base font-semibold text-gray-900 leading-snug",
                children: waypoint.label
            }, void 0, false, {
                fileName: "[project]/app/components/WaypointDetail.tsx",
                lineNumber: 30,
                columnNumber: 7
            }, this),
            waypoint.description && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-sm text-gray-700 leading-relaxed",
                children: waypoint.description
            }, void 0, false, {
                fileName: "[project]/app/components/WaypointDetail.tsx",
                lineNumber: 32,
                columnNumber: 9
            }, this),
            waypoint.notes && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-sm text-gray-500 border-t pt-3",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "font-medium text-gray-600 mb-1",
                        children: "Notes"
                    }, void 0, false, {
                        fileName: "[project]/app/components/WaypointDetail.tsx",
                        lineNumber: 36,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "leading-relaxed",
                        children: waypoint.notes
                    }, void 0, false, {
                        fileName: "[project]/app/components/WaypointDetail.tsx",
                        lineNumber: 37,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/components/WaypointDetail.tsx",
                lineNumber: 35,
                columnNumber: 9
            }, this),
            waypoint.filePath && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-sm text-gray-500 border-t pt-3",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "font-medium text-gray-600 mb-1",
                        children: "File Path"
                    }, void 0, false, {
                        fileName: "[project]/app/components/WaypointDetail.tsx",
                        lineNumber: 42,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "font-mono text-xs text-gray-700 break-all mb-2",
                        children: waypoint.filePath
                    }, void 0, false, {
                        fileName: "[project]/app/components/WaypointDetail.tsx",
                        lineNumber: 43,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex gap-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>{
                                    navigator.clipboard.writeText(waypoint.filePath).catch(()=>{});
                                    setCopied(true);
                                    setTimeout(()=>setCopied(false), 2000);
                                },
                                className: "px-2 py-1 text-xs border border-gray-200 rounded hover:bg-gray-50",
                                children: copied ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-green-600 font-medium",
                                    children: "Copied!"
                                }, void 0, false, {
                                    fileName: "[project]/app/components/WaypointDetail.tsx",
                                    lineNumber: 53,
                                    columnNumber: 25
                                }, this) : 'Copy path'
                            }, void 0, false, {
                                fileName: "[project]/app/components/WaypointDetail.tsx",
                                lineNumber: 45,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                href: `vscode://file/Users/mstorey/shrimp-2/${waypoint.filePath}`,
                                target: "_blank",
                                rel: "noreferrer",
                                className: "px-2 py-1 text-xs border border-gray-200 rounded hover:bg-gray-50",
                                children: "Open in VS Code"
                            }, void 0, false, {
                                fileName: "[project]/app/components/WaypointDetail.tsx",
                                lineNumber: 55,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/components/WaypointDetail.tsx",
                        lineNumber: 44,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/components/WaypointDetail.tsx",
                lineNumber: 41,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex gap-2 border-t pt-3",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>onEdit(waypoint),
                        className: "flex-1 px-3 py-1.5 text-sm border border-gray-300 rounded-lg hover:bg-gray-50",
                        children: "Edit"
                    }, void 0, false, {
                        fileName: "[project]/app/components/WaypointDetail.tsx",
                        lineNumber: 67,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>onDelete(waypoint.id),
                        className: "flex-1 px-3 py-1.5 text-sm border border-red-200 text-red-600 rounded-lg hover:bg-red-50",
                        children: "Delete"
                    }, void 0, false, {
                        fileName: "[project]/app/components/WaypointDetail.tsx",
                        lineNumber: 73,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/components/WaypointDetail.tsx",
                lineNumber: 66,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/components/WaypointDetail.tsx",
        lineNumber: 26,
        columnNumber: 5
    }, this);
}
_s(WaypointDetail, "NE86rL3vg4NVcTTWDavsT0hUBJs=");
_c = WaypointDetail;
var _c;
__turbopack_context__.k.register(_c, "WaypointDetail");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/lib/tour-markdown.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "generateTourMarkdown",
    ()=>generateTourMarkdown,
    "tourSlug",
    ()=>tourSlug
]);
function tourSlug(name) {
    return name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
}
function generateTourMarkdown(tour, waypoints) {
    const waypointMap = new Map(waypoints.map((w)=>[
            w.id,
            w
        ]));
    const lines = [];
    lines.push(`# ${tour.name}`);
    lines.push('');
    if (tour.description.trim()) {
        lines.push(tour.description);
        lines.push('');
    }
    lines.push(`*${tour.stops.length} stop${tour.stops.length === 1 ? '' : 's'}*`);
    lines.push('');
    tour.stops.forEach((stop, index)=>{
        const wp = waypointMap.get(stop.waypointId);
        if (!wp) return;
        lines.push('---');
        lines.push('');
        lines.push(`## Stop ${index + 1}: ${wp.label}`);
        lines.push('');
        if (wp.description?.trim()) {
            lines.push(wp.description);
            lines.push('');
        }
        if (wp.notes?.trim()) {
            lines.push(wp.notes);
            lines.push('');
        }
        if (wp.filePath?.trim()) {
            lines.push(`\`${wp.filePath}\``);
            lines.push('');
        }
        if (stop.narrative?.trim()) {
            lines.push(`> ${stop.narrative}`);
            lines.push('');
        }
    });
    return lines.join('\n');
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/TourBar.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>TourBar
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$tour$2d$markdown$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/lib/tour-markdown.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
function TourBar({ tours, activeTourId, activeTourStep, activeTourLength, onSelectTour, onNext, onPrev, onCreateTour, onUpdateTour, onDeleteTour, waypoints, markdownViewOpen, onToggleMarkdownView }) {
    _s();
    const [editor, setEditor] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        open: false,
        mode: 'create',
        name: '',
        description: '',
        stops: []
    });
    const isLast = activeTourLength > 0 && activeTourStep === activeTourLength - 1;
    const openCreate = ()=>setEditor({
            open: true,
            mode: 'create',
            name: '',
            description: '',
            stops: []
        });
    const openEdit = ()=>{
        const tour = tours.find((t)=>t.id === activeTourId);
        if (!tour) return;
        setEditor({
            open: true,
            mode: 'edit',
            tourId: tour.id,
            name: tour.name,
            description: tour.description,
            stops: tour.stops.map((s)=>({
                    ...s
                }))
        });
    };
    const closeEditor = ()=>setEditor((e)=>({
                ...e,
                open: false
            }));
    const saveEditor = ()=>{
        const data = {
            name: editor.name.trim(),
            description: editor.description.trim(),
            stops: editor.stops
        };
        if (!data.name) return;
        if (editor.mode === 'create') {
            onCreateTour(data);
        } else if (editor.tourId) {
            onUpdateTour(editor.tourId, data);
        }
        closeEditor();
    };
    const addWaypointToTour = (id)=>setEditor((e)=>({
                ...e,
                stops: [
                    ...e.stops,
                    {
                        waypointId: id
                    }
                ]
            }));
    const removeWaypointFromTour = (idx)=>setEditor((e)=>({
                ...e,
                stops: e.stops.filter((_, i)=>i !== idx)
            }));
    const moveWaypoint = (idx, dir)=>{
        setEditor((e)=>{
            const stops = [
                ...e.stops
            ];
            const target = idx + dir;
            if (target < 0 || target >= stops.length) return e;
            [stops[idx], stops[target]] = [
                stops[target],
                stops[idx]
            ];
            return {
                ...e,
                stops
            };
        });
    };
    const handleExport = ()=>{
        const tour = tours.find((t)=>t.id === activeTourId);
        if (!tour) return;
        const markdown = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$tour$2d$markdown$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["generateTourMarkdown"])(tour, waypoints);
        const filename = `${(0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$tour$2d$markdown$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tourSlug"])(tour.name)}-${new Date().toISOString().slice(0, 10)}.md`;
        const blob = new Blob([
            markdown
        ], {
            type: 'text/markdown'
        });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        a.click();
        URL.revokeObjectURL(url);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center gap-3 px-4 h-12 border-b border-gray-200 bg-white shrink-0",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                        className: "text-sm border border-gray-300 rounded px-2 py-1 bg-white",
                        value: activeTourId ?? '',
                        onChange: (e)=>onSelectTour(e.target.value || null),
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                value: "",
                                children: "No tour selected"
                            }, void 0, false, {
                                fileName: "[project]/app/components/TourBar.tsx",
                                lineNumber: 124,
                                columnNumber: 11
                            }, this),
                            tours.map((t)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                    value: t.id,
                                    children: t.name
                                }, t.id, false, {
                                    fileName: "[project]/app/components/TourBar.tsx",
                                    lineNumber: 126,
                                    columnNumber: 13
                                }, this))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/components/TourBar.tsx",
                        lineNumber: 119,
                        columnNumber: 9
                    }, this),
                    activeTourId ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: onPrev,
                                disabled: activeTourStep === 0,
                                className: "px-2 py-1 text-sm border rounded disabled:opacity-40 hover:bg-gray-50",
                                children: "← Prev"
                            }, void 0, false, {
                                fileName: "[project]/app/components/TourBar.tsx",
                                lineNumber: 132,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-sm text-gray-600 tabular-nums",
                                children: [
                                    "Step ",
                                    activeTourStep + 1,
                                    " of ",
                                    activeTourLength
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/components/TourBar.tsx",
                                lineNumber: 139,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: onNext,
                                className: "px-2 py-1 text-sm border rounded hover:bg-gray-50",
                                children: isLast ? 'Finish' : 'Next →'
                            }, void 0, false, {
                                fileName: "[project]/app/components/TourBar.tsx",
                                lineNumber: 142,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: openEdit,
                                className: "ml-1 px-2 py-1 text-xs border border-gray-200 rounded text-gray-500 hover:bg-gray-50",
                                children: "Edit tour"
                            }, void 0, false, {
                                fileName: "[project]/app/components/TourBar.tsx",
                                lineNumber: 148,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: onToggleMarkdownView,
                                className: `px-2 py-1 text-xs border rounded ${markdownViewOpen ? 'border-blue-400 bg-blue-50 text-blue-700' : 'border-gray-200 text-gray-500 hover:bg-gray-50'}`,
                                children: markdownViewOpen ? 'Graph' : 'Markdown'
                            }, void 0, false, {
                                fileName: "[project]/app/components/TourBar.tsx",
                                lineNumber: 154,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: handleExport,
                                className: "px-2 py-1 text-xs border border-gray-200 rounded text-gray-500 hover:bg-gray-50",
                                children: "Export ↓"
                            }, void 0, false, {
                                fileName: "[project]/app/components/TourBar.tsx",
                                lineNumber: 164,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/components/TourBar.tsx",
                        lineNumber: 131,
                        columnNumber: 11
                    }, this) : null,
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "ml-auto flex gap-2",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: openCreate,
                            className: "px-3 py-1 text-sm border border-gray-300 rounded hover:bg-gray-50",
                            children: "+ New Tour"
                        }, void 0, false, {
                            fileName: "[project]/app/components/TourBar.tsx",
                            lineNumber: 174,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/components/TourBar.tsx",
                        lineNumber: 173,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/components/TourBar.tsx",
                lineNumber: 118,
                columnNumber: 7
            }, this),
            editor.open && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "fixed inset-0 z-50 flex items-center justify-center bg-black/30",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "bg-white rounded-xl shadow-xl w-full max-w-lg p-6 flex flex-col gap-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            className: "text-base font-semibold",
                            children: editor.mode === 'create' ? 'New Tour' : 'Edit Tour'
                        }, void 0, false, {
                            fileName: "[project]/app/components/TourBar.tsx",
                            lineNumber: 188,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-col gap-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "text-sm font-medium",
                                    children: "Name *"
                                }, void 0, false, {
                                    fileName: "[project]/app/components/TourBar.tsx",
                                    lineNumber: 192,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    className: "border border-gray-300 rounded px-3 py-1.5 text-sm",
                                    value: editor.name,
                                    onChange: (e)=>setEditor((ed)=>({
                                                ...ed,
                                                name: e.target.value
                                            })),
                                    placeholder: "Tour name"
                                }, void 0, false, {
                                    fileName: "[project]/app/components/TourBar.tsx",
                                    lineNumber: 193,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/components/TourBar.tsx",
                            lineNumber: 191,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-col gap-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "text-sm font-medium",
                                    children: "Description"
                                }, void 0, false, {
                                    fileName: "[project]/app/components/TourBar.tsx",
                                    lineNumber: 201,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    className: "border border-gray-300 rounded px-3 py-1.5 text-sm",
                                    value: editor.description,
                                    onChange: (e)=>setEditor((ed)=>({
                                                ...ed,
                                                description: e.target.value
                                            })),
                                    placeholder: "One-line summary"
                                }, void 0, false, {
                                    fileName: "[project]/app/components/TourBar.tsx",
                                    lineNumber: 202,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/components/TourBar.tsx",
                            lineNumber: 200,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-col gap-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "text-sm font-medium",
                                    children: "Waypoints (ordered)"
                                }, void 0, false, {
                                    fileName: "[project]/app/components/TourBar.tsx",
                                    lineNumber: 210,
                                    columnNumber: 15
                                }, this),
                                editor.stops.length === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-xs text-gray-400",
                                    children: "No waypoints added yet."
                                }, void 0, false, {
                                    fileName: "[project]/app/components/TourBar.tsx",
                                    lineNumber: 212,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                    className: "flex flex-col gap-1",
                                    children: editor.stops.map((stop, idx)=>{
                                        const wp = waypoints.find((w)=>w.id === stop.waypointId);
                                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                            className: "flex flex-col gap-1 text-sm",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex items-center gap-2",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "flex-1 truncate",
                                                            children: wp?.label ?? stop.waypointId
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/components/TourBar.tsx",
                                                            lineNumber: 220,
                                                            columnNumber: 25
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                            onClick: ()=>moveWaypoint(idx, -1),
                                                            disabled: idx === 0,
                                                            className: "text-gray-400 hover:text-gray-700 disabled:opacity-30",
                                                            children: "↑"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/components/TourBar.tsx",
                                                            lineNumber: 221,
                                                            columnNumber: 25
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                            onClick: ()=>moveWaypoint(idx, 1),
                                                            disabled: idx === editor.stops.length - 1,
                                                            className: "text-gray-400 hover:text-gray-700 disabled:opacity-30",
                                                            children: "↓"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/components/TourBar.tsx",
                                                            lineNumber: 222,
                                                            columnNumber: 25
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                            onClick: ()=>removeWaypointFromTour(idx),
                                                            className: "text-red-400 hover:text-red-600",
                                                            children: "✕"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/components/TourBar.tsx",
                                                            lineNumber: 223,
                                                            columnNumber: 25
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/components/TourBar.tsx",
                                                    lineNumber: 219,
                                                    columnNumber: 23
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                                                    rows: 2,
                                                    className: "text-sm border border-gray-200 rounded px-2 py-1 w-full resize-none",
                                                    placeholder: "Narrative for this stop (optional)",
                                                    value: stop.narrative ?? '',
                                                    onChange: (ev)=>setEditor((ed)=>{
                                                            const stops = ed.stops.map((s, i)=>i === idx ? {
                                                                    ...s,
                                                                    narrative: ev.target.value
                                                                } : s);
                                                            return {
                                                                ...ed,
                                                                stops
                                                            };
                                                        })
                                                }, void 0, false, {
                                                    fileName: "[project]/app/components/TourBar.tsx",
                                                    lineNumber: 225,
                                                    columnNumber: 23
                                                }, this)
                                            ]
                                        }, `${stop.waypointId}-${idx}`, true, {
                                            fileName: "[project]/app/components/TourBar.tsx",
                                            lineNumber: 218,
                                            columnNumber: 21
                                        }, this);
                                    })
                                }, void 0, false, {
                                    fileName: "[project]/app/components/TourBar.tsx",
                                    lineNumber: 214,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                    className: "text-sm border border-gray-300 rounded px-2 py-1",
                                    defaultValue: "",
                                    onChange: (e)=>{
                                        if (e.target.value) {
                                            addWaypointToTour(e.target.value);
                                            e.target.value = '';
                                        }
                                    },
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                            value: "",
                                            children: "Add a waypoint…"
                                        }, void 0, false, {
                                            fileName: "[project]/app/components/TourBar.tsx",
                                            lineNumber: 244,
                                            columnNumber: 17
                                        }, this),
                                        [
                                            ...waypoints
                                        ].sort((a, b)=>a.label.localeCompare(b.label)).map((w)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: w.id,
                                                children: w.label
                                            }, w.id, false, {
                                                fileName: "[project]/app/components/TourBar.tsx",
                                                lineNumber: 246,
                                                columnNumber: 19
                                            }, this))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/components/TourBar.tsx",
                                    lineNumber: 239,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/components/TourBar.tsx",
                            lineNumber: 209,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex gap-2 items-center border-t pt-3",
                            children: [
                                editor.mode === 'edit' && editor.tourId && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: ()=>{
                                        onDeleteTour(editor.tourId);
                                        closeEditor();
                                    },
                                    className: "px-4 py-1.5 text-sm border border-red-300 text-red-600 rounded hover:bg-red-50 mr-auto",
                                    children: "Delete tour"
                                }, void 0, false, {
                                    fileName: "[project]/app/components/TourBar.tsx",
                                    lineNumber: 252,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: closeEditor,
                                    className: "px-4 py-1.5 text-sm border rounded hover:bg-gray-50",
                                    children: "Cancel"
                                }, void 0, false, {
                                    fileName: "[project]/app/components/TourBar.tsx",
                                    lineNumber: 259,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: saveEditor,
                                    disabled: !editor.name.trim(),
                                    className: "px-4 py-1.5 text-sm bg-blue-600 text-white rounded hover:bg-blue-700 disabled:opacity-40",
                                    children: "Save"
                                }, void 0, false, {
                                    fileName: "[project]/app/components/TourBar.tsx",
                                    lineNumber: 260,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/components/TourBar.tsx",
                            lineNumber: 250,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/components/TourBar.tsx",
                    lineNumber: 187,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/components/TourBar.tsx",
                lineNumber: 186,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true);
}
_s(TourBar, "L40mm5wPpJyiLiy7Hh/G1eHRoFY=");
_c = TourBar;
var _c;
__turbopack_context__.k.register(_c, "TourBar");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/TourMarkdownView.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>TourMarkdownView
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
'use client';
;
function TourMarkdownView({ tour, waypoints }) {
    const waypointMap = new Map(waypoints.map((w)=>[
            w.id,
            w
        ]));
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "h-full overflow-y-auto p-6 bg-white",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "max-w-2xl mx-auto",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                    className: "text-2xl font-bold text-gray-900 mb-2",
                    children: tour.name
                }, void 0, false, {
                    fileName: "[project]/app/components/TourMarkdownView.tsx",
                    lineNumber: 16,
                    columnNumber: 9
                }, this),
                tour.description?.trim() && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-gray-600 mb-3",
                    children: tour.description
                }, void 0, false, {
                    fileName: "[project]/app/components/TourMarkdownView.tsx",
                    lineNumber: 18,
                    columnNumber: 11
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-xs text-gray-400 mb-6",
                    children: [
                        tour.stops.length,
                        " stop",
                        tour.stops.length === 1 ? '' : 's'
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/components/TourMarkdownView.tsx",
                    lineNumber: 20,
                    columnNumber: 9
                }, this),
                tour.stops.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-sm text-gray-400 italic",
                    children: "This tour has no waypoints yet."
                }, void 0, false, {
                    fileName: "[project]/app/components/TourMarkdownView.tsx",
                    lineNumber: 25,
                    columnNumber: 11
                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-col gap-6",
                    children: tour.stops.map((stop, index)=>{
                        const wp = waypointMap.get(stop.waypointId);
                        if (!wp) return null;
                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "border-l-2 border-gray-200 pl-4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                    className: "text-base font-semibold text-gray-800 mb-1",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-gray-400 font-normal text-sm mr-2",
                                            children: [
                                                index + 1,
                                                "."
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/components/TourMarkdownView.tsx",
                                            lineNumber: 34,
                                            columnNumber: 21
                                        }, this),
                                        wp.label
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/components/TourMarkdownView.tsx",
                                    lineNumber: 33,
                                    columnNumber: 19
                                }, this),
                                wp.description?.trim() && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-sm text-gray-700 mb-2",
                                    children: wp.description
                                }, void 0, false, {
                                    fileName: "[project]/app/components/TourMarkdownView.tsx",
                                    lineNumber: 38,
                                    columnNumber: 21
                                }, this),
                                wp.notes?.trim() && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-sm text-gray-600 mb-2",
                                    children: wp.notes
                                }, void 0, false, {
                                    fileName: "[project]/app/components/TourMarkdownView.tsx",
                                    lineNumber: 41,
                                    columnNumber: 21
                                }, this),
                                wp.filePath?.trim() && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                    href: `vscode://file/Users/mstorey/shrimp-2/${wp.filePath}`,
                                    target: "_blank",
                                    rel: "noreferrer",
                                    className: "text-xs bg-gray-100 px-1.5 py-0.5 rounded text-gray-700 hover:bg-gray-200 block mb-2 font-mono break-all",
                                    children: wp.filePath
                                }, void 0, false, {
                                    fileName: "[project]/app/components/TourMarkdownView.tsx",
                                    lineNumber: 44,
                                    columnNumber: 21
                                }, this),
                                stop.narrative?.trim() && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "mt-2 border-l-2 border-amber-300 pl-3",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-sm text-amber-800 italic",
                                        children: stop.narrative
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/TourMarkdownView.tsx",
                                        lineNumber: 55,
                                        columnNumber: 23
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/components/TourMarkdownView.tsx",
                                    lineNumber: 54,
                                    columnNumber: 21
                                }, this)
                            ]
                        }, `${stop.waypointId}-${index}`, true, {
                            fileName: "[project]/app/components/TourMarkdownView.tsx",
                            lineNumber: 32,
                            columnNumber: 17
                        }, this);
                    })
                }, void 0, false, {
                    fileName: "[project]/app/components/TourMarkdownView.tsx",
                    lineNumber: 27,
                    columnNumber: 11
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/TourMarkdownView.tsx",
            lineNumber: 15,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/app/components/TourMarkdownView.tsx",
        lineNumber: 14,
        columnNumber: 5
    }, this);
}
_c = TourMarkdownView;
var _c;
__turbopack_context__.k.register(_c, "TourMarkdownView");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/WaypointForm.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>WaypointForm
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/lib/types.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
function WaypointForm({ mode, initialValues, onSave, onCancel }) {
    _s();
    const [label, setLabel] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialValues?.label ?? '');
    const [type, setType] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialValues?.type ?? '');
    const [description, setDescription] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialValues?.description ?? '');
    const [notes, setNotes] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialValues?.notes ?? '');
    const [filePath, setFilePath] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialValues?.filePath ?? '');
    const canSave = label.trim() !== '' && type !== '';
    const handleSave = ()=>{
        if (!canSave) return;
        onSave({
            label: label.trim(),
            type: type,
            description: description.trim() || undefined,
            notes: notes.trim() || undefined,
            filePath: filePath.trim() || undefined
        });
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "fixed inset-0 z-50 flex items-center justify-center bg-black/30",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "bg-white rounded-xl shadow-xl w-full max-w-md p-6 flex flex-col gap-4",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                    className: "text-base font-semibold",
                    children: mode === 'create' ? 'Add Waypoint' : 'Edit Waypoint'
                }, void 0, false, {
                    fileName: "[project]/app/components/WaypointForm.tsx",
                    lineNumber: 31,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-col gap-1.5",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                            className: "text-sm font-medium",
                            children: "Title *"
                        }, void 0, false, {
                            fileName: "[project]/app/components/WaypointForm.tsx",
                            lineNumber: 36,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                            autoFocus: true,
                            className: "border border-gray-300 rounded px-3 py-1.5 text-sm",
                            value: label,
                            onChange: (e)=>setLabel(e.target.value),
                            placeholder: "Short descriptive title"
                        }, void 0, false, {
                            fileName: "[project]/app/components/WaypointForm.tsx",
                            lineNumber: 37,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/components/WaypointForm.tsx",
                    lineNumber: 35,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-col gap-1.5",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                            className: "text-sm font-medium",
                            children: "Type *"
                        }, void 0, false, {
                            fileName: "[project]/app/components/WaypointForm.tsx",
                            lineNumber: 47,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                            className: "border border-gray-300 rounded px-3 py-1.5 text-sm bg-white",
                            value: type,
                            onChange: (e)=>setType(e.target.value),
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                    value: "",
                                    children: "Select a type…"
                                }, void 0, false, {
                                    fileName: "[project]/app/components/WaypointForm.tsx",
                                    lineNumber: 53,
                                    columnNumber: 13
                                }, this),
                                __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WAYPOINT_TYPES"].map((t)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: t,
                                        children: t
                                    }, t, false, {
                                        fileName: "[project]/app/components/WaypointForm.tsx",
                                        lineNumber: 55,
                                        columnNumber: 15
                                    }, this))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/components/WaypointForm.tsx",
                            lineNumber: 48,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/components/WaypointForm.tsx",
                    lineNumber: 46,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-col gap-1.5",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                            className: "text-sm font-medium",
                            children: [
                                "Description ",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-gray-400 font-normal",
                                    children: "(optional)"
                                }, void 0, false, {
                                    fileName: "[project]/app/components/WaypointForm.tsx",
                                    lineNumber: 61,
                                    columnNumber: 62
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/components/WaypointForm.tsx",
                            lineNumber: 61,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                            className: "border border-gray-300 rounded px-3 py-1.5 text-sm resize-none",
                            rows: 3,
                            value: description,
                            onChange: (e)=>setDescription(e.target.value),
                            placeholder: "What is this waypoint about?"
                        }, void 0, false, {
                            fileName: "[project]/app/components/WaypointForm.tsx",
                            lineNumber: 62,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/components/WaypointForm.tsx",
                    lineNumber: 60,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-col gap-1.5",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                            className: "text-sm font-medium",
                            children: [
                                "Notes ",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-gray-400 font-normal",
                                    children: "(optional)"
                                }, void 0, false, {
                                    fileName: "[project]/app/components/WaypointForm.tsx",
                                    lineNumber: 72,
                                    columnNumber: 56
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/components/WaypointForm.tsx",
                            lineNumber: 72,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                            className: "border border-gray-300 rounded px-3 py-1.5 text-sm resize-none",
                            rows: 2,
                            value: notes,
                            onChange: (e)=>setNotes(e.target.value),
                            placeholder: "Supplementary notes"
                        }, void 0, false, {
                            fileName: "[project]/app/components/WaypointForm.tsx",
                            lineNumber: 73,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/components/WaypointForm.tsx",
                    lineNumber: 71,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-col gap-1.5",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                            className: "text-sm font-medium",
                            children: [
                                "File Path ",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-gray-400 font-normal",
                                    children: "(optional)"
                                }, void 0, false, {
                                    fileName: "[project]/app/components/WaypointForm.tsx",
                                    lineNumber: 83,
                                    columnNumber: 60
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/components/WaypointForm.tsx",
                            lineNumber: 83,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                            className: "border border-gray-300 rounded px-3 py-1.5 text-sm font-mono",
                            value: filePath,
                            onChange: (e)=>setFilePath(e.target.value),
                            placeholder: "e.g. src/components/MyComponent.tsx"
                        }, void 0, false, {
                            fileName: "[project]/app/components/WaypointForm.tsx",
                            lineNumber: 84,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/components/WaypointForm.tsx",
                    lineNumber: 82,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex gap-2 justify-end border-t pt-3",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: onCancel,
                            className: "px-4 py-1.5 text-sm border border-gray-300 rounded hover:bg-gray-50",
                            children: "Cancel"
                        }, void 0, false, {
                            fileName: "[project]/app/components/WaypointForm.tsx",
                            lineNumber: 93,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: handleSave,
                            disabled: !canSave,
                            className: "px-4 py-1.5 text-sm bg-blue-600 text-white rounded hover:bg-blue-700 disabled:opacity-40",
                            children: "Save"
                        }, void 0, false, {
                            fileName: "[project]/app/components/WaypointForm.tsx",
                            lineNumber: 96,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/components/WaypointForm.tsx",
                    lineNumber: 92,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/WaypointForm.tsx",
            lineNumber: 30,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/app/components/WaypointForm.tsx",
        lineNumber: 29,
        columnNumber: 5
    }, this);
}
_s(WaypointForm, "KrNuMA8BMSqi4KIPyEqCSjVwU10=");
_c = WaypointForm;
var _c;
__turbopack_context__.k.register(_c, "WaypointForm");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/CognitiveToursApp.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>CognitiveToursApp
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/lib/types.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$WaypointGraph$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/WaypointGraph.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$WaypointDetail$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/WaypointDetail.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$TourBar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/TourBar.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$TourMarkdownView$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/TourMarkdownView.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$WaypointForm$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/WaypointForm.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
const JSON_HEADERS = {
    'Content-Type': 'application/json'
};
const DEFAULT_FILTER_STATE = Object.fromEntries(_c1 = __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WAYPOINT_TYPES"].map(_c = (t)=>[
        t,
        true
    ]));
_c2 = DEFAULT_FILTER_STATE;
async function apiFetch(url, options) {
    const res = await fetch(url, options);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
}
function CognitiveToursApp() {
    _s();
    const [waypoints, setWaypoints] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [edges, setEdges] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [tours, setTours] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [selectedWaypointId, setSelectedWaypointId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [activeTourId, setActiveTourId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [activeTourStep, setActiveTourStepRaw] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [form, setForm] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        open: false
    });
    const [loadState, setLoadState] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('loading');
    const [errorMessage, setErrorMessage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [filterState, setFilterState] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(DEFAULT_FILTER_STATE);
    const [searchQuery, setSearchQuery] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [markdownViewOpen, setMarkdownViewOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    // Per-node debounce map for position changes (onNodesChange fires on every drag frame).
    const positionDebounceMap = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(new Map());
    const selectedWaypoint = waypoints.find((w)=>w.id === selectedWaypointId) ?? null;
    const activeTour = tours.find((t)=>t.id === activeTourId) ?? null;
    const activeTourLength = activeTour?.stops.length ?? 0;
    const currentNarrative = activeTour?.stops[activeTourStep]?.narrative?.trim() ?? '';
    // T015: Startup fetch — load all persisted data on mount.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "CognitiveToursApp.useEffect": ()=>{
            void ({
                "CognitiveToursApp.useEffect": async ()=>{
                    try {
                        const res = await fetch('/api/data');
                        if (!res.ok) throw new Error(`HTTP ${res.status}`);
                        const data = await res.json();
                        setWaypoints(data.waypoints);
                        setEdges(data.edges);
                        setTours(data.tours);
                        setLoadState('ready');
                    } catch  {
                        setLoadState('error');
                    }
                }
            })["CognitiveToursApp.useEffect"]();
        }
    }["CognitiveToursApp.useEffect"], []);
    const clearErrorAfterDelay = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "CognitiveToursApp.useCallback[clearErrorAfterDelay]": ()=>{
            setTimeout({
                "CognitiveToursApp.useCallback[clearErrorAfterDelay]": ()=>setErrorMessage(null)
            }["CognitiveToursApp.useCallback[clearErrorAfterDelay]"], 5000);
        }
    }["CognitiveToursApp.useCallback[clearErrorAfterDelay]"], []);
    const selectWaypoint = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "CognitiveToursApp.useCallback[selectWaypoint]": (id)=>{
            setSelectedWaypointId(id);
        }
    }["CognitiveToursApp.useCallback[selectWaypoint]"], []);
    // T018
    const createWaypoint = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "CognitiveToursApp.useCallback[createWaypoint]": (data)=>{
            const id = `w-${Date.now()}`;
            const position = {
                x: 200 + Math.random() * 400,
                y: 200 + Math.random() * 300
            };
            const newWaypoint = {
                id,
                position,
                ...data
            };
            setWaypoints({
                "CognitiveToursApp.useCallback[createWaypoint]": (prev)=>[
                        ...prev,
                        newWaypoint
                    ]
            }["CognitiveToursApp.useCallback[createWaypoint]"]);
            void ({
                "CognitiveToursApp.useCallback[createWaypoint]": async ()=>{
                    try {
                        await apiFetch('/api/waypoints', {
                            method: 'POST',
                            headers: JSON_HEADERS,
                            body: JSON.stringify(newWaypoint)
                        });
                    } catch  {
                        setWaypoints({
                            "CognitiveToursApp.useCallback[createWaypoint]": (prev)=>prev.filter({
                                    "CognitiveToursApp.useCallback[createWaypoint]": (w)=>w.id !== id
                                }["CognitiveToursApp.useCallback[createWaypoint]"])
                        }["CognitiveToursApp.useCallback[createWaypoint]"]);
                        setErrorMessage('Failed to save waypoint.');
                        clearErrorAfterDelay();
                    }
                }
            })["CognitiveToursApp.useCallback[createWaypoint]"]();
        }
    }["CognitiveToursApp.useCallback[createWaypoint]"], [
        clearErrorAfterDelay
    ]);
    // T019
    const updateWaypoint = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "CognitiveToursApp.useCallback[updateWaypoint]": (id, data)=>{
            const original = waypoints.find({
                "CognitiveToursApp.useCallback[updateWaypoint].original": (w)=>w.id === id
            }["CognitiveToursApp.useCallback[updateWaypoint].original"]);
            if (!original) return;
            setWaypoints({
                "CognitiveToursApp.useCallback[updateWaypoint]": (prev)=>prev.map({
                        "CognitiveToursApp.useCallback[updateWaypoint]": (w)=>w.id === id ? {
                                ...w,
                                ...data
                            } : w
                    }["CognitiveToursApp.useCallback[updateWaypoint]"])
            }["CognitiveToursApp.useCallback[updateWaypoint]"]);
            void ({
                "CognitiveToursApp.useCallback[updateWaypoint]": async ()=>{
                    try {
                        await apiFetch(`/api/waypoints/${id}`, {
                            method: 'PUT',
                            headers: JSON_HEADERS,
                            body: JSON.stringify(data)
                        });
                    } catch  {
                        setWaypoints({
                            "CognitiveToursApp.useCallback[updateWaypoint]": (prev)=>prev.map({
                                    "CognitiveToursApp.useCallback[updateWaypoint]": (w)=>w.id === id ? original : w
                                }["CognitiveToursApp.useCallback[updateWaypoint]"])
                        }["CognitiveToursApp.useCallback[updateWaypoint]"]);
                        setErrorMessage('Failed to update waypoint.');
                        clearErrorAfterDelay();
                    }
                }
            })["CognitiveToursApp.useCallback[updateWaypoint]"]();
        }
    }["CognitiveToursApp.useCallback[updateWaypoint]"], [
        waypoints,
        clearErrorAfterDelay
    ]);
    // T021 — cascade: waypoint + its edges + tour membership
    const deleteWaypoint = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "CognitiveToursApp.useCallback[deleteWaypoint]": (id)=>{
            const waypointSnapshot = waypoints;
            const edgeSnapshot = edges;
            const tourSnapshot = tours;
            const removedEdges = edges.filter({
                "CognitiveToursApp.useCallback[deleteWaypoint].removedEdges": (e)=>e.source === id || e.target === id
            }["CognitiveToursApp.useCallback[deleteWaypoint].removedEdges"]);
            const modifiedTours = tours.filter({
                "CognitiveToursApp.useCallback[deleteWaypoint].modifiedTours": (t)=>t.stops.some({
                        "CognitiveToursApp.useCallback[deleteWaypoint].modifiedTours": (s)=>s.waypointId === id
                    }["CognitiveToursApp.useCallback[deleteWaypoint].modifiedTours"])
            }["CognitiveToursApp.useCallback[deleteWaypoint].modifiedTours"]).map({
                "CognitiveToursApp.useCallback[deleteWaypoint].modifiedTours": (t)=>({
                        ...t,
                        stops: t.stops.filter({
                            "CognitiveToursApp.useCallback[deleteWaypoint].modifiedTours": (s)=>s.waypointId !== id
                        }["CognitiveToursApp.useCallback[deleteWaypoint].modifiedTours"])
                    })
            }["CognitiveToursApp.useCallback[deleteWaypoint].modifiedTours"]);
            setWaypoints({
                "CognitiveToursApp.useCallback[deleteWaypoint]": (prev)=>prev.filter({
                        "CognitiveToursApp.useCallback[deleteWaypoint]": (w)=>w.id !== id
                    }["CognitiveToursApp.useCallback[deleteWaypoint]"])
            }["CognitiveToursApp.useCallback[deleteWaypoint]"]);
            setEdges({
                "CognitiveToursApp.useCallback[deleteWaypoint]": (prev)=>prev.filter({
                        "CognitiveToursApp.useCallback[deleteWaypoint]": (e)=>e.source !== id && e.target !== id
                    }["CognitiveToursApp.useCallback[deleteWaypoint]"])
            }["CognitiveToursApp.useCallback[deleteWaypoint]"]);
            setTours({
                "CognitiveToursApp.useCallback[deleteWaypoint]": (prev)=>prev.map({
                        "CognitiveToursApp.useCallback[deleteWaypoint]": (t)=>t.stops.some({
                                "CognitiveToursApp.useCallback[deleteWaypoint]": (s)=>s.waypointId === id
                            }["CognitiveToursApp.useCallback[deleteWaypoint]"]) ? {
                                ...t,
                                stops: t.stops.filter({
                                    "CognitiveToursApp.useCallback[deleteWaypoint]": (s)=>s.waypointId !== id
                                }["CognitiveToursApp.useCallback[deleteWaypoint]"])
                            } : t
                    }["CognitiveToursApp.useCallback[deleteWaypoint]"])
            }["CognitiveToursApp.useCallback[deleteWaypoint]"]);
            setSelectedWaypointId({
                "CognitiveToursApp.useCallback[deleteWaypoint]": (prev)=>prev === id ? null : prev
            }["CognitiveToursApp.useCallback[deleteWaypoint]"]);
            void ({
                "CognitiveToursApp.useCallback[deleteWaypoint]": async ()=>{
                    try {
                        await apiFetch(`/api/waypoints/${id}`, {
                            method: 'DELETE'
                        });
                        await Promise.all(removedEdges.map({
                            "CognitiveToursApp.useCallback[deleteWaypoint]": (e)=>apiFetch(`/api/edges/${e.id}`, {
                                    method: 'DELETE'
                                })
                        }["CognitiveToursApp.useCallback[deleteWaypoint]"]));
                        await Promise.all(modifiedTours.map({
                            "CognitiveToursApp.useCallback[deleteWaypoint]": (t)=>apiFetch(`/api/tours/${t.id}`, {
                                    method: 'PUT',
                                    headers: JSON_HEADERS,
                                    body: JSON.stringify({
                                        stops: t.stops
                                    })
                                })
                        }["CognitiveToursApp.useCallback[deleteWaypoint]"]));
                    } catch  {
                        setWaypoints(waypointSnapshot);
                        setEdges(edgeSnapshot);
                        setTours(tourSnapshot);
                        setErrorMessage('Failed to delete waypoint.');
                        clearErrorAfterDelay();
                    }
                }
            })["CognitiveToursApp.useCallback[deleteWaypoint]"]();
        }
    }["CognitiveToursApp.useCallback[deleteWaypoint]"], [
        waypoints,
        edges,
        tours,
        clearErrorAfterDelay
    ]);
    // T022
    const addEdge = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "CognitiveToursApp.useCallback[addEdge]": (connection)=>{
            if (connection.source === connection.target) return;
            const id = `e-${Date.now()}`;
            const newEdge = {
                id,
                ...connection
            };
            setEdges({
                "CognitiveToursApp.useCallback[addEdge]": (prev)=>[
                        ...prev,
                        newEdge
                    ]
            }["CognitiveToursApp.useCallback[addEdge]"]);
            void ({
                "CognitiveToursApp.useCallback[addEdge]": async ()=>{
                    try {
                        await apiFetch('/api/edges', {
                            method: 'POST',
                            headers: JSON_HEADERS,
                            body: JSON.stringify(newEdge)
                        });
                    } catch  {
                        setEdges({
                            "CognitiveToursApp.useCallback[addEdge]": (prev)=>prev.filter({
                                    "CognitiveToursApp.useCallback[addEdge]": (e)=>e.id !== id
                                }["CognitiveToursApp.useCallback[addEdge]"])
                        }["CognitiveToursApp.useCallback[addEdge]"]);
                        setErrorMessage('Failed to save connection.');
                        clearErrorAfterDelay();
                    }
                }
            })["CognitiveToursApp.useCallback[addEdge]"]();
        }
    }["CognitiveToursApp.useCallback[addEdge]"], [
        clearErrorAfterDelay
    ]);
    // T023
    const deleteEdge = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "CognitiveToursApp.useCallback[deleteEdge]": (id)=>{
            const snapshot = edges.find({
                "CognitiveToursApp.useCallback[deleteEdge].snapshot": (e)=>e.id === id
            }["CognitiveToursApp.useCallback[deleteEdge].snapshot"]);
            setEdges({
                "CognitiveToursApp.useCallback[deleteEdge]": (prev)=>prev.filter({
                        "CognitiveToursApp.useCallback[deleteEdge]": (e)=>e.id !== id
                    }["CognitiveToursApp.useCallback[deleteEdge]"])
            }["CognitiveToursApp.useCallback[deleteEdge]"]);
            void ({
                "CognitiveToursApp.useCallback[deleteEdge]": async ()=>{
                    try {
                        await apiFetch(`/api/edges/${id}`, {
                            method: 'DELETE'
                        });
                    } catch  {
                        if (snapshot) setEdges({
                            "CognitiveToursApp.useCallback[deleteEdge]": (prev)=>[
                                    ...prev,
                                    snapshot
                                ]
                        }["CognitiveToursApp.useCallback[deleteEdge]"]);
                        setErrorMessage('Failed to delete connection.');
                        clearErrorAfterDelay();
                    }
                }
            })["CognitiveToursApp.useCallback[deleteEdge]"]();
        }
    }["CognitiveToursApp.useCallback[deleteEdge]"], [
        edges,
        clearErrorAfterDelay
    ]);
    // T024
    const createTour = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "CognitiveToursApp.useCallback[createTour]": (data)=>{
            const id = `t-${Date.now()}`;
            const newTour = {
                id,
                ...data
            };
            setTours({
                "CognitiveToursApp.useCallback[createTour]": (prev)=>[
                        ...prev,
                        newTour
                    ]
            }["CognitiveToursApp.useCallback[createTour]"]);
            void ({
                "CognitiveToursApp.useCallback[createTour]": async ()=>{
                    try {
                        await apiFetch('/api/tours', {
                            method: 'POST',
                            headers: JSON_HEADERS,
                            body: JSON.stringify(newTour)
                        });
                    } catch  {
                        setTours({
                            "CognitiveToursApp.useCallback[createTour]": (prev)=>prev.filter({
                                    "CognitiveToursApp.useCallback[createTour]": (t)=>t.id !== id
                                }["CognitiveToursApp.useCallback[createTour]"])
                        }["CognitiveToursApp.useCallback[createTour]"]);
                        setErrorMessage('Failed to save tour.');
                        clearErrorAfterDelay();
                    }
                }
            })["CognitiveToursApp.useCallback[createTour]"]();
        }
    }["CognitiveToursApp.useCallback[createTour]"], [
        clearErrorAfterDelay
    ]);
    const deleteTour = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "CognitiveToursApp.useCallback[deleteTour]": (id)=>{
            const snapshot = tours;
            setTours({
                "CognitiveToursApp.useCallback[deleteTour]": (prev)=>prev.filter({
                        "CognitiveToursApp.useCallback[deleteTour]": (t)=>t.id !== id
                    }["CognitiveToursApp.useCallback[deleteTour]"])
            }["CognitiveToursApp.useCallback[deleteTour]"]);
            if (activeTourId === id) {
                setActiveTourId(null);
                setActiveTourStepRaw(0);
            }
            void ({
                "CognitiveToursApp.useCallback[deleteTour]": async ()=>{
                    try {
                        await apiFetch(`/api/tours/${id}`, {
                            method: 'DELETE'
                        });
                    } catch  {
                        setTours(snapshot);
                        setErrorMessage('Failed to delete tour.');
                        clearErrorAfterDelay();
                    }
                }
            })["CognitiveToursApp.useCallback[deleteTour]"]();
        }
    }["CognitiveToursApp.useCallback[deleteTour]"], [
        tours,
        activeTourId,
        clearErrorAfterDelay
    ]);
    // T025
    const updateTour = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "CognitiveToursApp.useCallback[updateTour]": (id, data)=>{
            const original = tours.find({
                "CognitiveToursApp.useCallback[updateTour].original": (t)=>t.id === id
            }["CognitiveToursApp.useCallback[updateTour].original"]);
            if (!original) return;
            setTours({
                "CognitiveToursApp.useCallback[updateTour]": (prev)=>prev.map({
                        "CognitiveToursApp.useCallback[updateTour]": (t)=>t.id === id ? {
                                ...t,
                                ...data
                            } : t
                    }["CognitiveToursApp.useCallback[updateTour]"])
            }["CognitiveToursApp.useCallback[updateTour]"]);
            void ({
                "CognitiveToursApp.useCallback[updateTour]": async ()=>{
                    try {
                        await apiFetch(`/api/tours/${id}`, {
                            method: 'PUT',
                            headers: JSON_HEADERS,
                            body: JSON.stringify(data)
                        });
                    } catch  {
                        setTours({
                            "CognitiveToursApp.useCallback[updateTour]": (prev)=>prev.map({
                                    "CognitiveToursApp.useCallback[updateTour]": (t)=>t.id === id ? original : t
                                }["CognitiveToursApp.useCallback[updateTour]"])
                        }["CognitiveToursApp.useCallback[updateTour]"]);
                        setErrorMessage('Failed to update tour.');
                        clearErrorAfterDelay();
                    }
                }
            })["CognitiveToursApp.useCallback[updateTour]"]();
        }
    }["CognitiveToursApp.useCallback[updateTour]"], [
        tours,
        clearErrorAfterDelay
    ]);
    const onToggleMarkdownView = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "CognitiveToursApp.useCallback[onToggleMarkdownView]": ()=>setMarkdownViewOpen({
                "CognitiveToursApp.useCallback[onToggleMarkdownView]": (v)=>!v
            }["CognitiveToursApp.useCallback[onToggleMarkdownView]"])
    }["CognitiveToursApp.useCallback[onToggleMarkdownView]"], []);
    const selectTour = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "CognitiveToursApp.useCallback[selectTour]": (id)=>{
            setActiveTourId(id);
            setActiveTourStepRaw(0);
            setMarkdownViewOpen(false);
            if (id) {
                const tour = tours.find({
                    "CognitiveToursApp.useCallback[selectTour].tour": (t)=>t.id === id
                }["CognitiveToursApp.useCallback[selectTour].tour"]);
                setSelectedWaypointId(tour?.stops[0]?.waypointId ?? null);
            }
        }
    }["CognitiveToursApp.useCallback[selectTour]"], [
        tours
    ]);
    const onNext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "CognitiveToursApp.useCallback[onNext]": ()=>{
            if (!activeTour) return;
            const next = activeTourStep + 1;
            if (next >= activeTour.stops.length) {
                setActiveTourId(null);
                return;
            }
            setActiveTourStepRaw(next);
            setSelectedWaypointId(activeTour.stops[next].waypointId);
        }
    }["CognitiveToursApp.useCallback[onNext]"], [
        activeTour,
        activeTourStep
    ]);
    const onPrev = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "CognitiveToursApp.useCallback[onPrev]": ()=>{
            if (!activeTour || activeTourStep === 0) return;
            const prev = activeTourStep - 1;
            setActiveTourStepRaw(prev);
            setSelectedWaypointId(activeTour.stops[prev].waypointId);
        }
    }["CognitiveToursApp.useCallback[onPrev]"], [
        activeTour,
        activeTourStep
    ]);
    // T020 — debounced per node ID: onNodesChange fires on every drag frame.
    const onNodePositionChange = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "CognitiveToursApp.useCallback[onNodePositionChange]": (id, position)=>{
            setWaypoints({
                "CognitiveToursApp.useCallback[onNodePositionChange]": (prev)=>prev.map({
                        "CognitiveToursApp.useCallback[onNodePositionChange]": (w)=>w.id === id ? {
                                ...w,
                                position
                            } : w
                    }["CognitiveToursApp.useCallback[onNodePositionChange]"])
            }["CognitiveToursApp.useCallback[onNodePositionChange]"]);
            const existing = positionDebounceMap.current.get(id);
            if (existing) clearTimeout(existing);
            positionDebounceMap.current.set(id, setTimeout({
                "CognitiveToursApp.useCallback[onNodePositionChange]": ()=>{
                    positionDebounceMap.current.delete(id);
                    void fetch(`/api/waypoints/${id}`, {
                        method: 'PUT',
                        headers: JSON_HEADERS,
                        body: JSON.stringify({
                            position
                        })
                    }).catch({
                        "CognitiveToursApp.useCallback[onNodePositionChange]": ()=>{
                            setErrorMessage('Failed to save position.');
                            clearErrorAfterDelay();
                        }
                    }["CognitiveToursApp.useCallback[onNodePositionChange]"]);
                }
            }["CognitiveToursApp.useCallback[onNodePositionChange]"], 500));
        }
    }["CognitiveToursApp.useCallback[onNodePositionChange]"], [
        clearErrorAfterDelay
    ]);
    const openCreateForm = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "CognitiveToursApp.useCallback[openCreateForm]": ()=>setForm({
                open: true,
                mode: 'create'
            })
    }["CognitiveToursApp.useCallback[openCreateForm]"], []);
    const openEditForm = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "CognitiveToursApp.useCallback[openEditForm]": (waypoint)=>setForm({
                open: true,
                mode: 'edit',
                waypoint
            })
    }["CognitiveToursApp.useCallback[openEditForm]"], []);
    const closeForm = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "CognitiveToursApp.useCallback[closeForm]": ()=>setForm({
                open: false
            })
    }["CognitiveToursApp.useCallback[closeForm]"], []);
    const handleFormSave = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "CognitiveToursApp.useCallback[handleFormSave]": (data)=>{
            if (form.open && form.mode === 'create') {
                createWaypoint(data);
            } else if (form.open && form.mode === 'edit') {
                updateWaypoint(form.waypoint.id, data);
            }
            closeForm();
        }
    }["CognitiveToursApp.useCallback[handleFormSave]"], [
        form,
        createWaypoint,
        updateWaypoint,
        closeForm
    ]);
    // T016: Loading and error states
    if (loadState === 'loading') {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex items-center justify-center h-screen text-gray-500",
            children: "Loading…"
        }, void 0, false, {
            fileName: "[project]/app/components/CognitiveToursApp.tsx",
            lineNumber: 364,
            columnNumber: 7
        }, this);
    }
    if (loadState === 'error') {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex items-center justify-center h-screen text-red-600",
            children: "Could not load data. Please refresh."
        }, void 0, false, {
            fileName: "[project]/app/components/CognitiveToursApp.tsx",
            lineNumber: 372,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex flex-col h-screen overflow-hidden",
        children: [
            errorMessage !== null && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-red-100 border-l-4 border-red-500 text-red-700 px-4 py-2 text-sm",
                children: errorMessage
            }, void 0, false, {
                fileName: "[project]/app/components/CognitiveToursApp.tsx",
                lineNumber: 382,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$TourBar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                tours: tours,
                activeTourId: activeTourId,
                activeTourStep: activeTourStep,
                activeTourLength: activeTourLength,
                onSelectTour: selectTour,
                onNext: onNext,
                onPrev: onPrev,
                onCreateTour: createTour,
                onUpdateTour: updateTour,
                onDeleteTour: deleteTour,
                waypoints: waypoints,
                markdownViewOpen: markdownViewOpen,
                onToggleMarkdownView: onToggleMarkdownView
            }, void 0, false, {
                fileName: "[project]/app/components/CognitiveToursApp.tsx",
                lineNumber: 386,
                columnNumber: 7
            }, this),
            !markdownViewOpen && currentNarrative && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-amber-50 border-l-4 border-amber-400 text-sm text-amber-900 px-4 py-2 shrink-0",
                children: currentNarrative
            }, void 0, false, {
                fileName: "[project]/app/components/CognitiveToursApp.tsx",
                lineNumber: 402,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-1 overflow-hidden",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex-1 relative overflow-hidden",
                        children: markdownViewOpen && activeTour ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$TourMarkdownView$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            tour: activeTour,
                            waypoints: waypoints
                        }, void 0, false, {
                            fileName: "[project]/app/components/CognitiveToursApp.tsx",
                            lineNumber: 409,
                            columnNumber: 13
                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$WaypointGraph$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            waypoints: waypoints,
                            edges: edges,
                            selectedWaypointId: selectedWaypointId,
                            activeTourWaypointIds: activeTour?.stops.map((s)=>s.waypointId) ?? [],
                            onSelectWaypoint: selectWaypoint,
                            onConnect: addEdge,
                            onDeleteEdge: deleteEdge,
                            onDeleteWaypoint: deleteWaypoint,
                            onNodePositionChange: onNodePositionChange,
                            onAddWaypointClick: openCreateForm,
                            filterState: filterState,
                            onFilterChange: (type, visible)=>setFilterState((prev)=>({
                                        ...prev,
                                        [type]: visible
                                    })),
                            searchQuery: searchQuery,
                            onSearchChange: setSearchQuery
                        }, void 0, false, {
                            fileName: "[project]/app/components/CognitiveToursApp.tsx",
                            lineNumber: 411,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/components/CognitiveToursApp.tsx",
                        lineNumber: 407,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "w-80 border-l border-gray-200 overflow-y-auto bg-white",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$WaypointDetail$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            waypoint: selectedWaypoint,
                            onEdit: openEditForm,
                            onDelete: deleteWaypoint
                        }, void 0, false, {
                            fileName: "[project]/app/components/CognitiveToursApp.tsx",
                            lineNumber: 430,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/components/CognitiveToursApp.tsx",
                        lineNumber: 429,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/components/CognitiveToursApp.tsx",
                lineNumber: 406,
                columnNumber: 7
            }, this),
            form.open && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$WaypointForm$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                mode: form.mode,
                initialValues: form.mode === 'edit' ? form.waypoint : undefined,
                onSave: handleFormSave,
                onCancel: closeForm
            }, void 0, false, {
                fileName: "[project]/app/components/CognitiveToursApp.tsx",
                lineNumber: 438,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/components/CognitiveToursApp.tsx",
        lineNumber: 379,
        columnNumber: 5
    }, this);
}
_s(CognitiveToursApp, "f82kl0DBDO3tAAkH7JsgL4qwyfk=");
_c3 = CognitiveToursApp;
var _c, _c1, _c2, _c3;
__turbopack_context__.k.register(_c, "DEFAULT_FILTER_STATE$Object.fromEntries$WAYPOINT_TYPES.map");
__turbopack_context__.k.register(_c1, "DEFAULT_FILTER_STATE$Object.fromEntries");
__turbopack_context__.k.register(_c2, "DEFAULT_FILTER_STATE");
__turbopack_context__.k.register(_c3, "CognitiveToursApp");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=app_0b.rhrh._.js.map